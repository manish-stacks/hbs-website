import { clients } from "@/data/home";

export function Logos() {
  return (
    <section className="border-y border-[var(--color-border)] bg-white py-9">
      <div className="container-max">
        <p className="text-center text-[var(--fs-xs)] font-bold uppercase tracking-[0.16em] text-[var(--color-text-muted)] sm:text-[var(--fs-sm)]">
          Trusted by 1500+ growing brands
        </p>
      </div>

      {/* RIGHT TO LEFT */}
      <div className="marquee-wrap mt-7 overflow-hidden">
        <div
          className="marquee"
          style={{
            ["--dur" as string]: "46s",
          }}
        >
          {[...clients, ...clients].map((c, i) => (
            <span
              key={i}
              className="mx-2.5 flex items-center gap-3 whitespace-nowrap rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface)] px-5 py-3.5 transition-colors duration-300 hover:border-[var(--color-brand)] sm:mx-3 sm:px-6"
            >
              <img
                src={c}
                alt="Client logo"
                className="h-6 w-auto object-contain sm:h-7"
              />
            </span>
          ))}
        </div>
      </div>

      {/* LEFT TO RIGHT */}
      <div className="marquee-wrap mt-8 overflow-hidden">
        <div
          className="marquee"
          style={{
            ["--dur" as string]: "46s",
            animationDirection: "reverse",
          }}
        >
          {[...clients, ...clients].map((c, i) => (
            <span
              key={i}
              className="mx-2.5 flex items-center gap-3 whitespace-nowrap rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-surface)] px-5 py-3.5 transition-colors duration-300 hover:border-[var(--color-brand)] sm:mx-3 sm:px-6"
            >
              <img
                src={c}
                alt="Client logo"
                className="h-6 w-auto object-contain sm:h-7"
              />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}