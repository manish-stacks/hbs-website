import Link from "next/link";
import type { CSSProperties, ReactNode } from "react";
import { ArrowRight, ArrowUpRight, Check, Minus, Phone, Plus, Sparkles } from "lucide-react";
import { buildMeta } from "@/lib/seo";
import { getCompany } from "@/lib/site";
import { LeadForm } from "@/components/svc/LeadForm";

export type PageData = {
  slug: string;
  title: string;
  eyebrow: string;
  tagline: string;
  intro: string;
  accent: string;
  metaTitle: string;
  metaDesc: string;
  benefits: { t: string; b: string }[];
  includes: string[];
  process: { t: string; b: string }[];
  faqs: { q: string; a: string }[];
  stats: [string, string][];
  related: { label: string; href: string }[];
};
export type Variant = "A" | "B" | "C" | "D" | "E" | "F" | "G" | "H";

export const pageMeta = (d: PageData) => buildMeta({ title: d.metaTitle, description: d.metaDesc, path: `/${d.slug}` });

const H1: CSSProperties = { letterSpacing: "-0.03em", lineHeight: 1.04 };
const h2c = "font-display font-black text-[var(--color-ink)]";
const h2s: CSSProperties = { fontSize: "var(--fs-3xl)", lineHeight: 1.1, letterSpacing: "-0.02em" };
const pill = "inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-[12px] font-bold uppercase tracking-[0.12em]";
const num = (i: number) => String(i + 1).padStart(2, "0");

type Co = Awaited<ReturnType<typeof getCompany>>;
type P = { d: PageData; co: Co };

function Faq({ d, dark = false }: { d: PageData; dark?: boolean }) {
  return (
    <div className={`divide-y ${dark ? "divide-white/10" : "divide-[var(--color-border)]"}`}>
      {d.faqs.map((f) => (
        <details key={f.q} className="group py-5">
          <summary className={`flex cursor-pointer list-none items-center justify-between gap-4 font-display text-[17px] font-bold ${dark ? "text-white" : "text-[var(--color-ink)]"}`}>
            {f.q}
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--a)]/10 text-[var(--a)]">
              <Plus size={16} className="group-open:hidden" /><Minus size={16} className="hidden group-open:block" />
            </span>
          </summary>
          <p className={`mt-3 max-w-[70ch] leading-relaxed ${dark ? "text-white/70" : "text-[var(--color-text-muted)]"}`}>{f.a}</p>
        </details>
      ))}
    </div>
  );
}

function Related({ d, dark = false }: { d: PageData; dark?: boolean }) {
  if (!d.related.length) return null;
  return (
    <div className="flex flex-wrap gap-2">
      {d.related.map((r) => (
        <Link key={r.href} href={r.href} className={`rounded-full border px-4 py-2 text-[13px] font-semibold transition-colors ${dark ? "border-white/20 text-white/80 hover:bg-white hover:text-black" : "border-[var(--color-border)] bg-white text-[var(--color-ink)] hover:border-[var(--a)] hover:text-[var(--a)]"}`}>{r.label}</Link>
      ))}
    </div>
  );
}

function Cta({ d, co, tone = "accent" }: P & { tone?: "accent" | "ink" | "soft" }) {
  const bg = tone === "accent" ? "bg-[var(--a)] text-white" : tone === "ink" ? "bg-[var(--color-ink)] text-white" : "bg-[var(--a)]/10 text-[var(--color-ink)]";
  return (
    <section className="py-10">
      <div className="container-max">
        <div className={`flex flex-col items-start justify-between gap-6 rounded-[28px] p-8 md:flex-row md:items-center md:p-12 ${bg}`}>
          <div>
            <h2 className="font-display text-[clamp(1.6rem,1.2rem+1.6vw,2.5rem)] font-black leading-tight">Ready to start with {d.title}?</h2>
            <p className="mt-2 max-w-[52ch] opacity-80">Tell us your goal and get a clear plan and quote within 48 hours. No obligation.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link href="/contact-us" className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 text-sm font-bold text-black transition-transform hover:-translate-y-0.5">Get a free quote <ArrowRight size={16} /></Link>
            <a href={`tel:${co.phone}`} className="inline-flex items-center gap-2 rounded-full border border-current/30 px-6 py-3.5 text-sm font-semibold"><Phone size={15} /> {co.phone}</a>
          </div>
        </div>
      </div>
    </section>
  );
}

const Btns = ({ co, dark = false }: { co: Co; dark?: boolean }) => (
  <div className="mt-8 flex flex-wrap gap-3">
    <Link href="/contact-us" className="group inline-flex items-center gap-3 rounded-full bg-[var(--a)] py-2 pl-6 pr-2 text-sm font-bold text-white shadow-[0_14px_34px_-12px_var(--a)]">
      Get free proposal <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/20 transition-transform group-hover:rotate-45"><ArrowRight size={16} /></span>
    </Link>
    <a href={`tel:${co.phone}`} className={`inline-flex items-center gap-2 rounded-full border px-6 py-3 text-sm font-semibold ${dark ? "border-white/25 text-white" : "border-[var(--color-border)] bg-white"}`}><Phone size={15} /> {co.phone}</a>
  </div>
);

/* A — Split light: text left, enquiry form right */
function A({ d, co }: P) {
  return (
    <>
      <section className="relative overflow-hidden bg-gradient-to-b from-[var(--a)]/[0.07] to-white pb-14 pt-12 md:pt-16">
        <div className="container-max grid items-center gap-10 lg:grid-cols-[1.15fr_.85fr]">
          <div>
            <span className={`${pill} bg-white text-[var(--a)] shadow-sm`}><Sparkles size={14} />{d.eyebrow}</span>
            <h1 className="mt-5 font-display font-black text-[var(--color-ink)]" style={{ ...H1, fontSize: "var(--fs-4xl)" }}>{d.title}</h1>
            <p className="mt-5 max-w-[56ch] text-[var(--fs-lg)] text-[var(--color-text-muted)]">{d.tagline}</p>
            <Btns co={co} />
            <dl className="mt-10 grid max-w-[520px] grid-cols-3 gap-4 border-t border-[var(--color-border)] pt-6">
              {d.stats.map(([v, l]) => (<div key={l}><dt className="font-display text-2xl font-black text-[var(--a)]">{v}</dt><dd className="text-[12px] text-[var(--color-text-muted)]">{l}</dd></div>))}
            </dl>
          </div>
          <div className="rounded-[28px] border border-[var(--color-border)] bg-white p-6 shadow-[var(--shadow-lg)] md:p-8">
            <p className="font-display text-xl font-black">Request a free quote</p>
            <p className="mb-5 mt-1 text-sm text-[var(--color-text-muted)]">We reply within one working day.</p>
            <LeadForm service={d.title} title={d.title} />
          </div>
        </div>
      </section>
      <section className="py-14"><div className="container-max">
        <h2 className={h2c} style={h2s}>Why choose us for {d.title}</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {d.benefits.map((b) => (<div key={b.t} className="rounded-2xl border border-[var(--color-border)] border-t-4 border-t-[var(--a)] bg-white p-6 shadow-[var(--shadow-sm)]"><h3 className="font-display text-lg font-bold">{b.t}</h3><p className="mt-2 text-sm leading-relaxed text-[var(--color-text-muted)]">{b.b}</p></div>))}
        </div>
      </div></section>
      <section className="bg-[var(--color-surface)] py-14"><div className="container-max grid gap-10 lg:grid-cols-[.8fr_1.2fr]">
        <div><h2 className={h2c} style={h2s}>What is included</h2><p className="mt-4 text-[var(--color-text-muted)]">{d.intro}</p></div>
        <ul className="grid gap-3 sm:grid-cols-2">{d.includes.map((i) => (<li key={i} className="flex items-start gap-3 rounded-xl bg-white p-4 shadow-[var(--shadow-sm)]"><span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--a)] text-white"><Check size={14} /></span><span className="font-medium">{i}</span></li>))}</ul>
      </div></section>
      <section className="py-14"><div className="container-max">
        <h2 className={`${h2c} text-center`} style={h2s}>How it works</h2>
        <div className="relative mt-10 grid gap-6 md:grid-cols-3">
          <div className="absolute inset-x-[16%] top-6 hidden h-px bg-[var(--a)]/30 md:block" />
          {d.process.map((s, i) => (<div key={s.t} className="relative text-center"><span className="relative mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[var(--a)] font-display font-black text-white ring-8 ring-white">{i + 1}</span><h3 className="mt-4 font-display text-lg font-bold">{s.t}</h3><p className="mx-auto mt-2 max-w-[32ch] text-sm text-[var(--color-text-muted)]">{s.b}</p></div>))}
        </div>
      </div></section>
      <section className="bg-[var(--color-surface)] py-14"><div className="container-max max-w-[860px]"><h2 className={`${h2c} mb-6 text-center`} style={h2s}>Frequently asked questions</h2><Faq d={d} /><div className="mt-8"><Related d={d} /></div></div></section>
      <Cta d={d} co={co} />
    </>
  );
}

/* B — Dark spotlight: centred hero, glass stats, bento, timeline */
function B({ d, co }: P) {
  return (
    <div className="bg-[#0b0e14] text-white">
      <section className="relative overflow-hidden pb-16 pt-16 text-center md:pt-24">
        <div className="pointer-events-none absolute left-1/2 top-0 h-[480px] w-[900px] -translate-x-1/2 rounded-full opacity-40 blur-[120px]" style={{ background: "var(--a)" }} />
        <div className="container-max relative">
          <span className={`${pill} border border-white/15 bg-white/5 text-white/80`}>{d.eyebrow}</span>
          <h1 className="mx-auto mt-6 max-w-[18ch] font-display font-black" style={{ ...H1, fontSize: "clamp(2.6rem,6vw,5rem)" }}>{d.title}</h1>
          <p className="mx-auto mt-5 max-w-[60ch] text-lg text-white/70">{d.tagline}</p>
          <div className="flex justify-center"><Btns co={co} dark /></div>
          <div className="mx-auto mt-14 grid max-w-[860px] grid-cols-3 gap-3">
            {d.stats.map(([v, l]) => (<div key={l} className="rounded-2xl border border-white/10 bg-white/5 p-5 backdrop-blur"><p className="font-display text-3xl font-black text-[var(--a)]">{v}</p><p className="mt-1 text-xs text-white/60">{l}</p></div>))}
          </div>
        </div>
      </section>
      <section className="py-14"><div className="container-max">
        <h2 className="font-display text-[clamp(1.8rem,1.4rem+1.6vw,2.7rem)] font-black">What you get</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-4 md:grid-rows-2">
          {d.benefits.map((b, i) => (<div key={b.t} className={`rounded-3xl border border-white/10 p-7 ${i === 0 ? "bg-[var(--a)] text-white md:col-span-2 md:row-span-2" : "bg-white/5"}`}><span className="font-display text-sm font-bold opacity-60">{num(i)}</span><h3 className={`mt-3 font-display font-bold ${i === 0 ? "text-3xl" : "text-lg"}`}>{b.t}</h3><p className={`mt-2 text-sm leading-relaxed ${i === 0 ? "text-white/85" : "text-white/60"}`}>{b.b}</p></div>))}
          <div className="rounded-3xl border border-white/10 bg-white/5 p-7 md:col-span-2"><h3 className="font-display text-lg font-bold">Included as standard</h3><ul className="mt-3 grid gap-2 text-sm text-white/70 sm:grid-cols-2">{d.includes.map((i) => (<li key={i} className="flex gap-2"><Check size={16} className="mt-0.5 shrink-0 text-[var(--a)]" />{i}</li>))}</ul></div>
        </div>
      </div></section>
      <section className="py-14"><div className="container-max grid gap-10 lg:grid-cols-[.7fr_1.3fr]">
        <h2 className="font-display text-[clamp(1.8rem,1.4rem+1.6vw,2.7rem)] font-black">Our process</h2>
        <ol className="relative ml-3 border-l border-white/15">{d.process.map((s, i) => (<li key={s.t} className="relative pb-10 pl-8 last:pb-0"><span className="absolute -left-[13px] top-0 flex h-6 w-6 items-center justify-center rounded-full bg-[var(--a)] text-[11px] font-black">{i + 1}</span><h3 className="font-display text-xl font-bold">{s.t}</h3><p className="mt-1 max-w-[52ch] text-white/60">{s.b}</p></li>))}</ol>
      </div></section>
      <section className="py-14"><div className="container-max max-w-[860px]"><h2 className="mb-4 font-display text-3xl font-black">Questions, answered</h2><Faq d={d} dark /><div className="mt-8"><Related d={d} dark /></div></div></section>
      <Cta d={d} co={co} />
    </div>
  );
}

/* C — Editorial: cream, huge type, numbered rows */
function C({ d, co }: P) {
  return (
    <div className="bg-[var(--color-surface)]">
      <section className="pb-14 pt-14 md:pt-20"><div className="container-max">
        <p className="text-[13px] font-bold uppercase tracking-[0.2em] text-[var(--a)]">{d.eyebrow}</p>
        <div className="mt-4 grid items-end gap-8 lg:grid-cols-[1.6fr_1fr]">
          <h1 className="font-display font-black text-[var(--color-ink)]" style={{ ...H1, fontSize: "clamp(3rem,8vw,6.5rem)", lineHeight: 0.98 }}>{d.title}<span className="text-[var(--a)]">.</span></h1>
          <div><p className="text-lg text-[var(--color-text-muted)]">{d.tagline}</p><Btns co={co} /></div>
        </div>
        <div className="mt-12 flex flex-wrap gap-x-12 gap-y-4 border-y border-[var(--color-ink)]/15 py-5">
          {d.stats.map(([v, l]) => (<p key={l} className="flex items-baseline gap-3"><span className="font-display text-4xl font-black">{v}</span><span className="text-sm text-[var(--color-text-muted)]">{l}</span></p>))}
        </div>
      </div></section>
      <section className="py-10"><div className="container-max">
        {d.benefits.map((b, i) => (<div key={b.t} className="grid gap-3 border-b border-[var(--color-ink)]/15 py-8 md:grid-cols-[100px_1fr_1.3fr] md:items-baseline"><span className="font-display text-5xl font-black text-[var(--a)]">{num(i)}</span><h3 className="font-display text-2xl font-bold">{b.t}</h3><p className="text-[var(--color-text-muted)]">{b.b}</p></div>))}
      </div></section>
      <section className="py-12"><div className="container-max"><h2 className={h2c} style={h2s}>In scope</h2><p className="mt-3 max-w-[60ch] text-[var(--color-text-muted)]">{d.intro}</p>
        <div className="mt-6 flex flex-wrap gap-2">{d.includes.map((i) => (<span key={i} className="rounded-full bg-white px-4 py-2 text-sm font-medium shadow-[var(--shadow-sm)]">{i}</span>))}</div></div></section>
      <section className="py-12"><div className="container-max"><h2 className={h2c} style={h2s}>Three steps</h2>
        <div className="mt-8 grid gap-8 md:grid-cols-3">{d.process.map((s, i) => (<div key={s.t}><p className="font-display text-[7rem] font-black leading-none text-[var(--a)]/20">{i + 1}</p><h3 className="-mt-6 font-display text-xl font-bold">{s.t}</h3><p className="mt-2 text-[var(--color-text-muted)]">{s.b}</p></div>))}</div></div></section>
      <section className="py-12"><div className="container-max grid gap-10 lg:grid-cols-[1fr_1.6fr]"><div><h2 className={h2c} style={h2s}>Good to know</h2><div className="mt-5"><Related d={d} /></div></div><Faq d={d} /></div></section>
      <Cta d={d} co={co} tone="ink" />
    </div>
  );
}

/* D — Gradient centre with zig-zag rows */
function D({ d, co }: P) {
  return (
    <>
      <section className="relative overflow-hidden pb-16 pt-14 text-center md:pt-20" style={{ background: "radial-gradient(60% 70% at 50% 0%, color-mix(in srgb, var(--a) 22%, white), white 70%)" }}>
        <div className="container-max">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--a)] text-white shadow-[0_18px_40px_-12px_var(--a)]"><Sparkles size={28} /></span>
          <p className="mt-5 text-[13px] font-bold uppercase tracking-[0.18em] text-[var(--a)]">{d.eyebrow}</p>
          <h1 className="mx-auto mt-3 max-w-[20ch] font-display font-black text-[var(--color-ink)]" style={{ ...H1, fontSize: "clamp(2.4rem,5.6vw,4.6rem)" }}>{d.title}</h1>
          <p className="mx-auto mt-5 max-w-[58ch] text-lg text-[var(--color-text-muted)]">{d.tagline}</p>
          <div className="flex justify-center"><Btns co={co} /></div>
          <ul className="mx-auto mt-10 flex max-w-[820px] flex-wrap justify-center gap-2">{d.includes.slice(0, 5).map((i) => (<li key={i} className="flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-[13px] font-semibold shadow-[var(--shadow-sm)]"><Check size={14} className="text-[var(--a)]" />{i}</li>))}</ul>
        </div>
      </section>
      <section className="py-12"><div className="container-max space-y-6">
        {d.benefits.map((b, i) => (<div key={b.t} className={`grid items-center gap-6 rounded-3xl border border-[var(--color-border)] bg-white p-6 shadow-[var(--shadow-sm)] md:grid-cols-[220px_1fr] md:p-8 ${i % 2 ? "md:[&>*:first-child]:order-2 md:grid-cols-[1fr_220px]" : ""}`}>
          <div className="flex h-36 items-center justify-center rounded-2xl bg-[var(--a)]/10 font-display text-7xl font-black text-[var(--a)]">{num(i)}</div>
          <div><h3 className="font-display text-2xl font-bold">{b.t}</h3><p className="mt-2 max-w-[56ch] text-[var(--color-text-muted)]">{b.b}</p></div>
        </div>))}
      </div></section>
      <section className="bg-[var(--color-ink)] py-14 text-white"><div className="container-max"><h2 className="text-center font-display text-3xl font-black">Our process</h2>
        <div className="mt-10 grid gap-8 md:grid-cols-3">{d.process.map((s, i) => (<div key={s.t} className="text-center"><span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border-2 border-[var(--a)] font-display text-3xl font-black text-[var(--a)]">{i + 1}</span><h3 className="mt-4 font-display text-xl font-bold">{s.t}</h3><p className="mx-auto mt-2 max-w-[30ch] text-sm text-white/60">{s.b}</p></div>))}</div></div></section>
      <section className="py-14"><div className="container-max max-w-[860px]"><h2 className={`${h2c} mb-4 text-center`} style={h2s}>FAQs</h2><Faq d={d} /><div className="mt-8 flex justify-center"><Related d={d} /></div></div></section>
      <Cta d={d} co={co} tone="soft" />
    </>
  );
}

/* E — Accent band hero with form, overlapping stats, side FAQ */
function E({ d, co }: P) {
  return (
    <>
      <section className="bg-[var(--a)] pb-28 pt-12 text-white md:pt-16"><div className="container-max grid items-center gap-10 lg:grid-cols-[1.1fr_.9fr]">
        <div>
          <p className="text-[13px] font-bold uppercase tracking-[0.18em] text-white/70">{d.eyebrow}</p>
          <h1 className="mt-3 font-display font-black" style={{ ...H1, fontSize: "var(--fs-4xl)" }}>{d.title}</h1>
          <p className="mt-5 max-w-[54ch] text-lg text-white/85">{d.tagline}</p>
          <ul className="mt-6 space-y-2">{d.includes.slice(0, 4).map((i) => (<li key={i} className="flex items-center gap-2 font-medium"><Check size={18} />{i}</li>))}</ul>
        </div>
        <div className="rounded-3xl bg-white p-6 text-[var(--color-ink)] shadow-[var(--shadow-lg)] md:p-8"><p className="font-display text-xl font-black">Talk to a specialist</p><p className="mb-5 mt-1 text-sm text-[var(--color-text-muted)]">Free consultation, no obligation.</p><LeadForm service={d.title} title={d.title} /></div>
      </div></section>
      <div className="container-max -mt-14"><dl className="grid grid-cols-3 divide-x divide-[var(--color-border)] rounded-2xl bg-white py-6 text-center shadow-[var(--shadow-md)]">{d.stats.map(([v, l]) => (<div key={l}><dt className="font-display text-2xl font-black text-[var(--a)] md:text-4xl">{v}</dt><dd className="text-xs text-[var(--color-text-muted)] md:text-sm">{l}</dd></div>))}</dl></div>
      <section className="py-14"><div className="container-max"><h2 className={h2c} style={h2s}>Why teams pick us</h2>
        <div className="mt-8 divide-y divide-[var(--color-border)] rounded-3xl border border-[var(--color-border)] bg-white">{d.benefits.map((b, i) => (<div key={b.t} className="flex gap-5 p-6"><span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[var(--a)]/10 font-display font-black text-[var(--a)]">{i + 1}</span><div><h3 className="font-display text-lg font-bold">{b.t}</h3><p className="mt-1 text-[var(--color-text-muted)]">{b.b}</p></div></div>))}</div></div></section>
      <section className="py-10"><div className="container-max"><h2 className={`${h2c} mb-8`} style={h2s}>From first call to results</h2>
        <div className="grid gap-5 md:grid-cols-3">{d.process.map((s, i) => (<div key={s.t} className="relative rounded-2xl bg-[var(--a)]/[0.07] p-6 pt-10"><span className="absolute -top-5 left-6 flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--a)] font-display font-black text-white">{i + 1}</span><h3 className="font-display text-lg font-bold">{s.t}</h3><p className="mt-2 text-sm text-[var(--color-text-muted)]">{s.b}</p></div>))}</div></div></section>
      <section className="py-14"><div className="container-max grid gap-10 lg:grid-cols-[.8fr_1.4fr]"><div className="lg:sticky lg:top-28 lg:self-start"><h2 className={h2c} style={h2s}>Common questions</h2><p className="mt-3 text-[var(--color-text-muted)]">{d.intro}</p><div className="mt-5"><Related d={d} /></div></div><Faq d={d} /></div></section>
      <Cta d={d} co={co} tone="ink" />
    </>
  );
}

/* F — Bento grid hero and tinted tiles */
function F({ d, co }: P) {
  return (
    <>
      <section className="py-10 md:py-14"><div className="container-max grid gap-4 md:grid-cols-6">
        <div className="rounded-[32px] bg-[var(--color-ink)] p-8 text-white md:col-span-4 md:row-span-2 md:p-12">
          <span className={`${pill} bg-white/10 text-white/80`}>{d.eyebrow}</span>
          <h1 className="mt-5 font-display font-black" style={{ ...H1, fontSize: "clamp(2.4rem,5vw,4.2rem)" }}>{d.title}</h1>
          <p className="mt-4 max-w-[50ch] text-white/70">{d.tagline}</p><Btns co={co} dark />
        </div>
        {d.stats.slice(0, 2).map(([v, l], i) => (<div key={l} className={`flex flex-col justify-end rounded-[32px] p-7 md:col-span-2 ${i ? "bg-[var(--color-surface-2)]" : "bg-[var(--a)]/15"}`}><p className="font-display text-5xl font-black text-[var(--a)]">{v}</p><p className="text-sm text-[var(--color-text-muted)]">{l}</p></div>))}
        <div className="rounded-[32px] border border-[var(--color-border)] p-7 md:col-span-6"><div className="flex flex-wrap items-center gap-x-8 gap-y-2">{d.includes.map((i) => (<span key={i} className="flex items-center gap-2 text-sm font-semibold"><Check size={15} className="text-[var(--a)]" />{i}</span>))}</div></div>
      </div></section>
      <section className="py-10"><div className="container-max"><h2 className={h2c} style={h2s}>What sets us apart</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2">{d.benefits.map((b, i) => (<div key={b.t} className={`rounded-[28px] p-8 ${["bg-[var(--a)]/10", "bg-[var(--color-surface-2)]", "bg-[var(--color-surface-2)]", "bg-[var(--a)]/10"][i % 4]}`}><h3 className="font-display text-xl font-bold">{b.t}</h3><p className="mt-2 text-[var(--color-text-muted)]">{b.b}</p></div>))}</div></div></section>
      <section className="py-12"><div className="container-max grid gap-10 lg:grid-cols-[.7fr_1.3fr]"><div className="lg:sticky lg:top-28 lg:self-start"><h2 className={h2c} style={h2s}>How we work</h2><p className="mt-3 text-[var(--color-text-muted)]">{d.intro}</p></div>
        <div className="space-y-4">{d.process.map((s, i) => (<div key={s.t} className="flex gap-5 rounded-3xl border border-[var(--color-border)] bg-white p-6"><span className="font-display text-5xl font-black text-[var(--a)]">{num(i)}</span><div><h3 className="font-display text-xl font-bold">{s.t}</h3><p className="mt-1 text-[var(--color-text-muted)]">{s.b}</p></div></div>))}</div></div></section>
      <section className="py-12"><div className="container-max max-w-[860px]"><Faq d={d} /><div className="mt-8"><Related d={d} /></div></div></section>
      <Cta d={d} co={co} />
    </>
  );
}

/* G — Half accent hero, big numerals, chevron steps */
function G({ d, co }: P) {
  return (
    <>
      <section className="grid lg:grid-cols-2">
        <div className="flex flex-col justify-center bg-[var(--a)] px-6 py-16 text-white md:px-16 lg:py-24">
          <p className="text-[13px] font-bold uppercase tracking-[0.18em] text-white/70">{d.eyebrow}</p>
          <h1 className="mt-3 font-display font-black" style={{ ...H1, fontSize: "clamp(2.4rem,5vw,4.2rem)" }}>{d.title}</h1>
          <p className="mt-5 max-w-[48ch] text-white/85">{d.tagline}</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link href="/contact-us" className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 text-sm font-bold text-black">Get free proposal <ArrowRight size={16} /></Link><a href={`tel:${co.phone}`} className="inline-flex items-center gap-2 rounded-full border border-white/40 px-6 py-3.5 text-sm font-semibold"><Phone size={15} />{co.phone}</a></div>
        </div>
        <div className="flex items-center bg-[var(--color-surface)] px-6 py-14 md:px-16"><div className="w-full rounded-3xl bg-white p-8 shadow-[var(--shadow-md)]"><p className="font-display text-lg font-black">What is included</p><ul className="mt-4 space-y-3">{d.includes.map((i) => (<li key={i} className="flex items-center gap-3 border-b border-[var(--color-border)] pb-3 last:border-0"><ArrowUpRight size={16} className="text-[var(--a)]" />{i}</li>))}</ul></div></div>
      </section>
      <section className="py-14"><div className="container-max grid gap-8 md:grid-cols-2 lg:grid-cols-4">{d.benefits.map((b, i) => (<div key={b.t}><p className="font-display text-7xl font-black text-[var(--a)]/25">{num(i)}</p><h3 className="-mt-3 font-display text-lg font-bold">{b.t}</h3><p className="mt-2 text-sm text-[var(--color-text-muted)]">{b.b}</p></div>))}</div></section>
      <section className="border-y border-[var(--color-border)] bg-[var(--color-surface)] py-6"><div className="container-max grid grid-cols-3 text-center">{d.stats.map(([v, l]) => (<div key={l}><p className="font-display text-3xl font-black">{v}</p><p className="text-xs text-[var(--color-text-muted)]">{l}</p></div>))}</div></section>
      <section className="py-14"><div className="container-max"><h2 className={`${h2c} mb-8`} style={h2s}>The process</h2>
        <div className="grid gap-3 md:grid-cols-3">{d.process.map((s, i) => (<div key={s.t} className="bg-[var(--a)]/[0.08] p-7 md:[clip-path:polygon(0_0,92%_0,100%_50%,92%_100%,0_100%,8%_50%)] md:px-14 md:first:[clip-path:polygon(0_0,92%_0,100%_50%,92%_100%,0_100%)]"><p className="text-xs font-bold text-[var(--a)]">STEP {i + 1}</p><h3 className="font-display text-lg font-bold">{s.t}</h3><p className="mt-1 text-sm text-[var(--color-text-muted)]">{s.b}</p></div>))}</div></div></section>
      <section className="pb-14"><div className="container-max grid gap-x-12 lg:grid-cols-2"><div><h2 className={`${h2c} mb-2`} style={h2s}>FAQs</h2><Faq d={d} /></div><div className="pt-4 lg:pt-16"><p className="mb-3 font-semibold">Related services</p><Related d={d} /></div></div></section>
      <Cta d={d} co={co} tone="ink" />
    </>
  );
}

/* H — Minimal list: thin lines, big rows */
function H({ d, co }: P) {
  return (
    <>
      <section className="border-b border-[var(--color-border)] py-14 md:py-20"><div className="container-max">
        <p className="flex items-center gap-3 text-sm font-semibold text-[var(--color-text-muted)]"><span className="h-px w-10 bg-[var(--a)]" />{d.eyebrow}</p>
        <h1 className="mt-5 max-w-[16ch] font-display font-black text-[var(--color-ink)]" style={{ ...H1, fontSize: "clamp(2.6rem,6vw,5.2rem)" }}>{d.title}</h1>
        <div className="mt-6 grid gap-6 md:grid-cols-2"><p className="text-lg text-[var(--color-text-muted)]">{d.tagline}</p><div className="md:text-right"><Link href="/contact-us" className="inline-flex items-center gap-2 border-b-2 border-[var(--a)] pb-1 font-display text-lg font-bold">Start a project <ArrowRight size={18} /></Link></div></div>
      </div></section>
      <section className="py-10"><div className="container-max">
        {d.benefits.map((b, i) => (<div key={b.t} className="group grid gap-2 border-b border-[var(--color-border)] py-7 transition-colors hover:bg-[var(--a)]/[0.05] md:grid-cols-[80px_1fr_1.2fr] md:px-4"><span className="text-sm font-bold text-[var(--a)]">{num(i)}</span><h3 className="font-display text-xl font-bold">{b.t}</h3><p className="text-[var(--color-text-muted)]">{b.b}</p></div>))}
      </div></section>
      <section className="py-12"><div className="container-max grid gap-10 md:grid-cols-2">
        <div><h2 className={h2c} style={h2s}>Scope</h2><ul className="mt-5 divide-y divide-[var(--color-border)] border-y border-[var(--color-border)]">{d.includes.map((i) => (<li key={i} className="flex items-center justify-between py-3"><span>{i}</span><Check size={16} className="text-[var(--a)]" /></li>))}</ul></div>
        <div><h2 className={h2c} style={h2s}>Process</h2><ol className="mt-5 space-y-6">{d.process.map((s, i) => (<li key={s.t} className="flex gap-4"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-[var(--a)] text-sm font-bold text-[var(--a)]">{i + 1}</span><div><h3 className="font-display font-bold">{s.t}</h3><p className="text-sm text-[var(--color-text-muted)]">{s.b}</p></div></li>))}</ol></div>
      </div></section>
      <section className="py-12"><div className="container-max max-w-[820px]"><Faq d={d} /></div></section>
      <section className="pb-6"><div className="container-max"><Related d={d} /></div></section>
      <Cta d={d} co={co} tone="ink" />
    </>
  );
}

const MAP = { A, B, C, D, E, F, G, H } as const;

export async function PageView({ d, v }: { d: PageData; v: Variant }) {
  const co = await getCompany();
  const L = MAP[v];
  return (
    <div className="theme-hbs pv text-[var(--color-ink)]" style={{ "--a": d.accent } as CSSProperties}>
      <style>{".pv h1,.pv h2,.pv h3{color:inherit}"}</style>
      <L d={d} co={co} />
    </div>
  );
}

export type { ReactNode };
