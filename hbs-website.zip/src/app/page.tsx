import { Hero } from "@/components/home/Hero";
import { Logos } from "@/components/home/Logos";
import { About } from "@/components/home/About";
import { Stats } from "@/components/home/Stats";
import { Services } from "@/components/home/Services";
import { Process } from "@/components/home/Process";
import { Problems } from "@/components/home/Problems";
import { Results } from "@/components/home/Results";
import { WhyUs } from "@/components/home/WhyUs";
import { Offices } from "@/components/home/Offices";
import { Industries } from "@/components/home/Industries";
import { Testimonials } from "@/components/home/Testimonials";
import { Blog } from "@/components/home/Blog";
import { Faq } from "@/components/home/Faq";
import { ContactCTA } from "@/components/home/ContactCTA";
import { TeamSection } from "@/components/home/TeamSection";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Logos />
      <About />
      <Stats />
      <Services />
      <Process />
      <Problems />
      <TeamSection />
      <WhyUs />
      <Offices />
      <Industries />
      <Testimonials />
      <Blog />
      <ContactCTA />
      <Faq />
    </>
  );
}
