import { PageView, pageMeta, type PageData } from "@/components/pages/layouts";

// Edit the text below to change this page. Layout style: B
const d: PageData = {
  "slug": "video-editing",
  "title": "Video Editing",
  "eyebrow": "Creative Studio",
  "tagline": "Professional editing for ads, reels, explainers and corporate videos.",
  "intro": "Professional editing for ads, reels, explainers and corporate videos. Hover Business Services LLP handles Video Editing from planning to delivery, with a clear scope, regular updates and one point of contact.",
  "accent": "#ea580c",
  "metaTitle": "Video Editing | Hover Business Services LLP",
  "metaDesc": "Professional editing for ads, reels, explainers and corporate videos. Get a free quote from Hover Business Services LLP.",
  "benefits": [
    {
      "t": "Brand-first thinking",
      "b": "Every design starts from your brand, audience and goals."
    },
    {
      "t": "Multiple concepts",
      "b": "You choose a direction before we refine it."
    },
    {
      "t": "Ready-to-use files",
      "b": "Print, web and social formats delivered together."
    },
    {
      "t": "Revisions included",
      "b": "Agreed revision rounds so the result matches your brief."
    }
  ],
  "includes": [
    "Cuts, colour and sound",
    "Captions and motion graphics",
    "Platform-ready formats",
    "Agreed revision rounds",
    "Source and final files",
    "Brand-consistent output"
  ],
  "process": [
    {
      "t": "Brief",
      "b": "We learn your brand, audience and goals."
    },
    {
      "t": "Design",
      "b": "You receive concepts, then refine them with us."
    },
    {
      "t": "Deliver",
      "b": "Final files are prepared for web, print or social."
    }
  ],
  "faqs": [
    {
      "q": "How many revisions are included?",
      "a": "Scope includes agreed revision rounds so the final result matches your brief."
    },
    {
      "q": "Do I receive the source files?",
      "a": "Yes. You receive final files and source files once the project is approved."
    },
    {
      "q": "How long does design take?",
      "a": "Most projects take 1 to 3 weeks, depending on size and feedback speed."
    }
  ],
  "stats": [
    [
      "5+",
      "Years in business"
    ],
    [
      "1500+",
      "Happy clients"
    ],
    [
      "24/7",
      "Support available"
    ]
  ],
  "related": [
    {
      "label": "Logo Design",
      "href": "/logo-design"
    },
    {
      "label": "Social Media Creatives",
      "href": "/social-media-creatives"
    },
    {
      "label": "UI/UX Design",
      "href": "/ui-ux-design"
    },
    {
      "label": "Product Packaging Design",
      "href": "/product-packaging-design"
    }
  ]
};

export const generateMetadata = () => pageMeta(d);
export default function Page() {
  return <PageView d={d} v="B" />;
}
