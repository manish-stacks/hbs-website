import type { Metadata } from "next";
import { buildMeta } from "@/lib/seo";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, ArrowUpRight, CalendarDays, Clock, Phone, User } from "lucide-react";
import { PageCta } from "@/components/layout/PageCta";
import { Reveal } from "@/components/ui/Reveal";
import { ServiceHero } from "@/components/layout/ServiceHero";
import { serviceTheme } from "@/lib/serviceTheme";
import { Underline } from "@/components/ui/Decor";
import { blogPosts, postMap, postSlugs } from "@/data/blog";
import { company } from "@/data/home";

export function generateStaticParams() {
  return postSlugs.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const p = postMap.get(slug);
  return p ? buildMeta({ title: p.title, description: p.excerpt, path: `/blog/${slug}`, type: "article" }) : {};
}

export default async function BlogDetail({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = postMap.get(slug);
  if (!post) notFound();

  const more = blogPosts.filter((p) => p.slug !== post.slug).slice(0, 3);

  return (
    <>
      <article>
        <ServiceHero
          eyebrow={post.tag}
          title={post.title}
          tagline={post.excerpt}
          crumbs={[{ label: "Blog", href: "/blog" }, { label: post.title, href: `/blog/${post.slug}` }]}
          theme={{ ...serviceTheme("custom-web-design"), image: post.image, label: post.tag }}
          phone={company.phone}
        />

        <section className="section-space">
          <div className="container-max grid gap-10 lg:grid-cols-[1fr_350px] lg:items-start lg:gap-14">
            <div>
              <Reveal>
                <span className="pill">Article</span>
                <h2 className="relative mt-4 inline-block" style={{ fontSize: "var(--fs-2xl)" }}>
                  {post.title}
                  <Underline className="absolute -bottom-2 left-0 h-3 w-[46%] min-w-[120px]" />
                </h2>
                <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-[var(--fs-sm)] text-[var(--color-text-muted)]">
                  <span className="inline-flex items-center gap-2"><User size={15} className="text-[var(--color-brand)]" /> {post.author}</span>
                  <span className="inline-flex items-center gap-2"><CalendarDays size={15} className="text-[var(--color-brand)]" /> {post.date.full}</span>
                  <span className="inline-flex items-center gap-2"><Clock size={15} className="text-[var(--color-brand)]" /> {post.readTime}</span>
                </div>
              </Reveal>

              <Reveal stagger className="mt-10 flex flex-col gap-4">
                {post.body.map((b, i) =>
                  b.heading ? (
                    <div key={i} className="group relative overflow-hidden rounded-[var(--radius-md)] border border-[var(--color-border)] bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-md)] sm:p-7">
                      <span className="absolute right-5 top-4 font-display text-4xl font-extrabold text-[var(--color-ink)]/[.05] transition-colors group-hover:text-[var(--color-brand)]/15">
                        {String(i).padStart(2, "0")}
                      </span>
                      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--color-brand)] to-[var(--color-brand-dark)] font-display text-lg font-extrabold text-white shadow-[0_10px_22px_color-mix(in_srgb,var(--color-brand)_35%,transparent)]">
                        {i}
                      </span>
                      <h3 className="mt-5 font-display text-[var(--fs-xl)] font-bold">{b.heading}</h3>
                      <p className="mt-2 leading-[1.8] text-[var(--color-text-muted)]">{b.text}</p>
                    </div>
                  ) : (
                    <p key={i} className="text-[var(--fs-lg)] leading-[1.8] text-[var(--color-text-muted)]">{b.text}</p>
                  ),
                )}
              </Reveal>
            </div>

            <aside className="flex flex-col gap-6 lg:sticky lg:top-[130px]">
              <div className="relative overflow-hidden rounded-[var(--radius-lg)] bg-[var(--color-ink)] p-7 text-white">
                <span className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-[var(--color-brand)] opacity-50 blur-3xl" />
                <p className="relative font-display text-xl font-bold leading-snug text-white">Want results like this for your business?</p>
                <p className="relative mt-2 text-[var(--fs-sm)] text-white/70">Get a free audit and a clear plan within 48 hours.</p>
                <Link href="/free-website-audit" className="btn btn-brand relative mt-5 w-full justify-center">Free website audit</Link>
                <a href={`tel:${company.phone}`} className="relative mt-3 flex items-center justify-center gap-2 text-[var(--fs-sm)] font-semibold text-white/85 hover:text-white"><Phone size={14} /> {company.phone}</a>
              </div>
              <div className="rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white p-6 shadow-[var(--shadow-sm)]">
                <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[var(--color-brand)]">Talk to us</p>
                <p className="mt-2 text-[var(--fs-sm)] text-[var(--color-text-muted)]">Have a project in mind? Share the details and we will reply with a clear scope.</p>
                <Link href="/contact-us" className="btn btn-brand mt-4 w-full justify-center">Talk to a strategist <ArrowRight size={16} /></Link>
              </div>
            </aside>
          </div>
        </section>
      </article>

      {/* related */}
      <section className="section-space bg-[var(--color-surface)]">
        <div className="container-max">
          <h2 className="text-center" style={{ fontSize: "var(--fs-2xl)" }}>Keep reading</h2>
          <Reveal stagger className="mx-auto mt-10 grid max-w-[1100px] gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {more.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="group flex flex-col overflow-hidden rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white shadow-[var(--shadow-sm)] transition-all hover:-translate-y-1.5 hover:shadow-[var(--shadow-md)]">
                <div className="relative aspect-[16/9] overflow-hidden">
                  <Image src={p.image} alt={p.title} fill sizes="360px" className="object-cover transition-transform duration-700 group-hover:scale-110" />
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--color-brand)]">{p.tag}</span>
                  <h3 className="mt-2 text-[var(--fs-lg)] font-bold leading-snug transition-colors group-hover:text-[var(--color-brand)]">{p.title}</h3>
                  <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-[var(--fs-xs)] font-bold uppercase tracking-wider text-[var(--color-ink)]">Read <ArrowUpRight size={14} /></span>
                </div>
              </Link>
            ))}
          </Reveal>
        </div>
      </section>

      <PageCta />
    </>
  );
}
