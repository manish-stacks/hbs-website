import type { Metadata } from "next";
import { buildMeta } from "@/lib/seo";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { PageHero } from "@/components/layout/PageHero";
import { PageCta } from "@/components/layout/PageCta";
import { Reveal } from "@/components/ui/Reveal";
import { Industries } from "@/components/home/Industries";
import { Testimonials } from "@/components/home/Testimonials";
import { results, stats } from "@/data/home";

export const metadata: Metadata = buildMeta({
  title: "Portfolio",
  description: "Selected client work and measurable results from Hover Business Services LLP.",
  path: "/portfolio",
});

const work = [
  {
    name: "EFOS",
    key: "food",
    sector: "Food services",
    scope: ["Web platform", "SEO", "Branding"],
    outcome: "Rebuilt the site and search presence around service-intent keywords.",
    image: "/images/company/efos.jpg",
  },
  {
    name: "PrintHutt",
    key: "ecommerce",
    sector: "E-commerce",
    scope: ["Store build", "Performance marketing"],
    outcome: "Custom print storefront with a paid funnel tuned to order value.",
    image: "/images/company/printhutt.avif",
  },
  {
    name: "OncoHealthMart",
    key: "healthcare",
    sector: "Healthcare",
    scope: ["E-commerce SEO", "Rebuild"],
    outcome: "Catalogue site turned into a transacting store with trust signals.",
    image: "/images/company/onco.png",
  },
  {
    name: "Dikshant",
    key: "education",
    sector: "Education",
    scope: ["Website", "Admissions funnel"],
    outcome: "Course pages and lead routing built around the admission season.",
    image: "/images/company/dikshant.avif",
  },
  {
    name: "Becho Gadi",
    key: "marketplace",
    sector: "Marketplace",
    scope: ["Platform", "Lead generation"],
    outcome: "Listing marketplace with a qualified-seller acquisition engine.",
    image: "/images/company/becho-gadi.webp",
  },
];

/**
 * CSS-only filter: a hidden radio per sector + Tailwind `has-*` variants.
 * Class strings are written out in full so Tailwind can detect them.
 */
const filters = [
  { key: "all", label: "All", cls: "" },
  { key: "ecommerce", label: "E-commerce", cls: "has-[#f-ecommerce:checked]:[&_article:not([data-s=ecommerce])]:hidden" },
  { key: "healthcare", label: "Healthcare", cls: "has-[#f-healthcare:checked]:[&_article:not([data-s=healthcare])]:hidden" },
  { key: "education", label: "Education", cls: "has-[#f-education:checked]:[&_article:not([data-s=education])]:hidden" },
  { key: "marketplace", label: "Marketplace", cls: "has-[#f-marketplace:checked]:[&_article:not([data-s=marketplace])]:hidden" },
  { key: "food", label: "Food services", cls: "has-[#f-food:checked]:[&_article:not([data-s=food])]:hidden" },
];

export default function PortfolioPage() {
  return (
    <>
      <PageHero
        eyebrow="Our work"
        title="Work we are happy to be judged on"
        tagline="Sites, stores and campaigns we have shipped — and what changed after launch."
        crumbs={[{ label: "Portfolio", href: "/portfolio" }]}
      />

      {/* stats */}
      <section className="relative z-10 -mt-2 pb-4">
        <div className="container-max">
          <Reveal className="grid grid-cols-2 divide-x divide-y divide-[var(--color-border)] overflow-hidden rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white shadow-[var(--shadow-md)] lg:grid-cols-4 lg:divide-y-0">
            {stats.map((s) => (
              <div key={s.label} className="px-4 py-7 text-center sm:py-9">
                <p className="font-display text-3xl font-extrabold text-[var(--color-ink)] sm:text-4xl">
                  {s.value.toLocaleString("en-IN")}
                  <span className="text-[var(--color-brand)]">{s.suffix}</span>
                </p>
                <p className="mt-1 text-[var(--fs-xs)] font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
                  {s.label}
                </p>
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      {/* work */}
      <section className="section-space">
        <div className="container-max">
          <Reveal className="mx-auto max-w-[60ch] text-center">
            <span className="pill">Selected work</span>
            <h2 className="mt-4" style={{ fontSize: "var(--fs-3xl)" }}>
              Projects built to <span className="text-gradient-brand">perform</span>
            </h2>
          </Reveal>

          <div className={`mt-10 ${filters.map((f) => f.cls).join(" ")}`}>
            <div role="radiogroup" aria-label="Filter projects by industry" className="flex flex-wrap justify-center gap-2">
              {filters.map((f) => (
                <label
                  key={f.key}
                  htmlFor={`f-${f.key}`}
                  className="cursor-pointer rounded-full border border-[var(--color-border)] bg-white px-5 py-2.5 text-[var(--fs-xs)] font-semibold text-[var(--color-text-muted)] transition hover:border-[var(--color-ink)] has-[:checked]:border-[var(--color-ink)] has-[:checked]:bg-[var(--color-ink)] has-[:checked]:text-white has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-[var(--color-brand)] sm:text-[var(--fs-sm)]"
                >
                  <input type="radio" name="sector" id={`f-${f.key}`} defaultChecked={f.key === "all"} className="sr-only" />
                  {f.label}
                </label>
              ))}
            </div>

            <Reveal stagger className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {work.map((w, i) => (
                <article
                  key={w.name}
                  data-s={w.key}
                  className="group flex flex-col overflow-hidden rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white shadow-[var(--shadow-sm)] transition-all duration-300 hover:-translate-y-1.5 hover:border-[var(--color-ink)]/20 hover:shadow-[var(--shadow-lg)]"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-[var(--color-surface-2)]">
                    <Image
                      src={w.image}
                      alt={`${w.name} — ${w.sector} project by Hover Business Services`}
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 400px"
                      className="object-cover transition-transform duration-[900ms] group-hover:scale-105"
                    />
                    <div
                      className="absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                      style={{ background: "linear-gradient(180deg, transparent 40%, rgba(16,19,26,.7))" }}
                    />
                    <span className="absolute left-4 top-4 rounded-full bg-white/95 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-[var(--color-ink)] shadow-sm">
                      {w.sector}
                    </span>
                    <span className="absolute bottom-4 right-4 flex h-11 w-11 translate-y-3 items-center justify-center rounded-full bg-[var(--color-brand)] text-white opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                      <ArrowUpRight size={18} />
                    </span>
                  </div>

                  <div className="flex flex-1 flex-col p-6">
                    <div className="flex items-baseline justify-between gap-3">
                      <h3 className="font-display text-[var(--fs-xl)] font-extrabold">{w.name}</h3>
                      <span className="font-display text-sm font-bold text-[var(--color-border)]">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                    </div>
                    <p className="mt-2 flex-1 text-[var(--fs-sm)] leading-relaxed text-[var(--color-text-muted)]">{w.outcome}</p>
                    <ul className="mt-5 flex flex-wrap gap-2 border-t border-[var(--color-border)] pt-5">
                      {w.scope.map((s) => (
                        <li key={s} className="rounded-full bg-[var(--color-surface)] px-3 py-1 text-[12px] font-medium text-[var(--color-ink)]">
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}

              <Link
                href="/contact-us"
                className="group relative flex min-h-[280px] flex-col items-center justify-center gap-3 overflow-hidden rounded-[var(--radius-lg)] bg-[var(--color-ink)] p-8 text-center text-white transition-transform duration-300 hover:-translate-y-1.5"
              >
                <span
                  className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full blur-[70px]"
                  style={{ background: "radial-gradient(circle, rgba(229,35,27,.55), transparent 70%)" }}
                />
                <span className="relative flex h-14 w-14 items-center justify-center rounded-full bg-[var(--color-brand)] transition-transform group-hover:translate-x-1">
                  <ArrowRight size={22} />
                </span>
                <p className="relative font-display text-[var(--fs-xl)] font-extrabold">Your brand here</p>
                <p className="relative max-w-[28ch] text-[var(--fs-sm)] text-white/60">
                  Tell us what you are building and we will show you a plan.
                </p>
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* case studies */}
      <section className="section-space relative overflow-hidden bg-[var(--color-ink)] text-white">
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px)",
            backgroundSize: "52px 52px",
            maskImage: "radial-gradient(ellipse at center, #000 25%, transparent 75%)",
          }}
        />
        <div
          className="pointer-events-none absolute -left-40 top-0 h-[420px] w-[420px] rounded-full blur-[120px]"
          style={{ background: "radial-gradient(circle, rgba(229,35,27,.3), transparent 70%)" }}
        />

        <div className="container-max relative">
          <Reveal className="mx-auto max-w-[56ch] text-center">
            <span className="inline-flex rounded-full border border-white/15 bg-white/5 px-4 py-2 text-[12px] font-semibold uppercase tracking-[0.12em] text-white/80">
              Case studies
            </span>
            <h2 className="mt-4 text-white" style={{ fontSize: "var(--fs-3xl)" }}>
              What changed after we <span className="text-gradient-brand">took over</span>
            </h2>
          </Reveal>

          <Reveal stagger className="mt-12 grid gap-5 lg:grid-cols-3">
            {results.map((r) => (
              <article
                key={r.industry}
                className="flex flex-col overflow-hidden rounded-[var(--radius-lg)] border border-white/10 bg-white/[.04] transition-colors duration-300 hover:border-[var(--color-brand)]/50 hover:bg-white/[.07]"
              >
                <div className="grid grid-cols-3 gap-3 border-b border-white/10 bg-white/[.04] p-6">
                  {r.metrics.map(([v, l]) => (
                    <div key={l}>
                      <p className="text-gradient-brand font-display text-2xl font-extrabold sm:text-3xl">{v}</p>
                      <p className="mt-1 text-[11px] leading-tight text-white/55">{l}</p>
                    </div>
                  ))}
                </div>

                <div className="flex flex-1 flex-col p-6 sm:p-7">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-full bg-[var(--color-brand)]/15 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-[#ff8a82]">
                      {r.industry}
                    </span>
                    <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/45">{r.client}</span>
                  </div>

                  <h3 className="mt-5 text-[11px] font-bold uppercase tracking-[0.16em] text-[var(--color-accent)]">The challenge</h3>
                  <p className="mt-1.5 text-[var(--fs-sm)] leading-relaxed text-white/70">{r.challenge}</p>

                  <h3 className="mt-5 text-[11px] font-bold uppercase tracking-[0.16em] text-[var(--color-accent)]">What we did</h3>
                  <p className="mt-1.5 flex-1 text-[var(--fs-sm)] leading-relaxed text-white/70">{r.solution}</p>
                </div>
              </article>
            ))}
          </Reveal>
        </div>
      </section>

      <Testimonials />
      <Industries />
      <PageCta title="Want results like these on your account?" />
    </>
  );
}
