import { HubDesign, hubMeta, type HubData } from "@/components/pages/hubs";

// Edit the text below to change this page.
const h: HubData = {
  "slug": "graphic-design",
  "metaTitle": "Creative & Design Services | Hover Business Services LLP",
  "metaDesc": "Logo design, graphic design, video editing, UI/UX and packaging from Hover Business Services LLP.",
  "eyebrow": "Creative & Design",
  "title": "Design that makes brands remembered",
  "tagline": "Logos, graphics, video, social creatives and interface design from one creative studio.",
  "accent": "#ea580c",
  "groups": [
    {
      "title": "Creative Studio",
      "sub": "Logos, graphics, video and interface design.",
      "items": [
        {
          "label": "Logo Design",
          "href": "/logo-design",
          "body": "Memorable logos and brand marks that suit every size and platform."
        },
        {
          "label": "Video Editing",
          "href": "/video-editing",
          "body": "Professional editing for ads, reels, explainers and corporate videos."
        },
        {
          "label": "Social Media Creatives",
          "href": "/social-media-creatives",
          "body": "Scroll-stopping posts, carousels and ad creatives."
        },
        {
          "label": "UI/UX Design",
          "href": "/ui-ux-design",
          "body": "User-friendly interfaces backed by research and testing."
        },
        {
          "label": "Product Packaging Design",
          "href": "/product-packaging-design",
          "body": "Packaging that stands out on the shelf and tells your product story."
        }
      ]
    }
  ],
  "why": [
    {
      "t": "One accountable team",
      "b": "Strategy, design, development and marketing under one roof."
    },
    {
      "t": "Clear scope and pricing",
      "b": "You know what you get and what it costs before we start."
    },
    {
      "t": "24/7 support",
      "b": "Reach us any time through phone, email or WhatsApp."
    }
  ]
};

export const generateMetadata = () => hubMeta(h);
export default function Page() {
  return <HubDesign h={h} />;
}
