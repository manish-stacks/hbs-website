import { PageView, pageMeta, type PageData } from "@/components/pages/layouts";

// Edit the text below to change this page. Layout style: B
const d: PageData = {
  "slug": "digital-pr",
  "title": "Digital PR",
  "eyebrow": "Content & Link Building",
  "tagline": "Earn press coverage and brand mentions that strengthen trust and search visibility.",
  "intro": "Earn press coverage and brand mentions that strengthen trust and search visibility. Hover Business Services LLP handles Digital PR from planning to delivery, with a clear scope, regular updates and one point of contact.",
  "accent": "#d97706",
  "metaTitle": "Digital PR | Hover Business Services LLP",
  "metaDesc": "Earn press coverage and brand mentions that strengthen trust and search visibility. Get a free quote from Hover Business Services LLP.",
  "benefits": [
    {
      "t": "Strategy before spend",
      "b": "Every plan starts with an audit of your market, competitors and goals."
    },
    {
      "t": "Specialists, not generalists",
      "b": "Each channel is handled by a dedicated expert."
    },
    {
      "t": "Plain-English reporting",
      "b": "Monthly reports show what we did, what changed and what is next."
    },
    {
      "t": "No lock-in",
      "b": "Month-to-month work after the initial set-up, with full ownership of your accounts."
    }
  ],
  "includes": [
    "Story angles and pitches",
    "Journalist outreach",
    "Coverage and link report",
    "Dedicated account manager",
    "Clear monthly reporting",
    "No hidden fees"
  ],
  "process": [
    {
      "t": "Audit and plan",
      "b": "We review your site, competitors and goals, then agree a clear plan."
    },
    {
      "t": "Execute",
      "b": "Our specialists carry out the plan with weekly progress updates."
    },
    {
      "t": "Measure and improve",
      "b": "Monthly reports show what worked and what we will do next."
    }
  ],
  "faqs": [
    {
      "q": "How soon will I see results?",
      "a": "Paid campaigns can produce leads within weeks. SEO and content usually compound over 3 to 6 months."
    },
    {
      "q": "Will I see what you are doing?",
      "a": "Yes. You get a clear monthly report with actions taken, key numbers and next steps."
    },
    {
      "q": "Is there a long lock-in?",
      "a": "No. After an initial set-up period we work month to month."
    }
  ],
  "stats": [
    [
      "5+",
      "Years in business"
    ],
    [
      "1500+",
      "Happy clients"
    ],
    [
      "24/7",
      "Support available"
    ]
  ],
  "related": [
    {
      "label": "Content Writing",
      "href": "/content-writing"
    },
    {
      "label": "Link Building",
      "href": "/link-building"
    },
    {
      "label": "Blog Outreach",
      "href": "/blog-outreach"
    },
    {
      "label": "Guest Posting",
      "href": "/guest-posting"
    }
  ]
};

export const generateMetadata = () => pageMeta(d);
export default function Page() {
  return <PageView d={d} v="B" />;
}
