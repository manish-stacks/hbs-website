export type BlockType = "article" | "hero" | "heading" | "text" | "split" | "steps" | "stats" | "image" | "features" | "checklist" | "faq" | "cta";
export type Block = { id: string; type: BlockType; [k: string]: unknown };
export type Field = { k: string; label: string; t: "text" | "area" | "rich" | "image" | "lines" | "items" | "icon" | "video" | "select"; sub?: Field[]; hint?: string; options?: string[] };

export const BLOCKS: Record<BlockType, { label: string; fields: Field[]; init: Record<string, unknown> }> = {
  article: { label: "Article", fields: [{ k: "body", label: "Content", t: "rich" }], init: { body: "" } },
  hero: {
    label: "Hero banner",
    fields: [
      { k: "eyebrow", label: "Eyebrow", t: "text" },
      { k: "title", label: "Title", t: "text" },
      { k: "tagline", label: "Tagline", t: "area" },
      { k: "image", label: "Background image (optional)", t: "image" },
    ],
    init: { eyebrow: "Service", title: "Page title", tagline: "Short supporting line", image: "" },
  },
  heading: {
    label: "Section heading",
    fields: [
      { k: "text", label: "Heading", t: "text" },
      { k: "sub", label: "Sub text", t: "area" },
    ],
    init: { text: "Section heading", sub: "" },
  },
  text: {
    label: "Text",
    fields: [
      { k: "heading", label: "Heading (optional)", t: "text" },
      { k: "body", label: "Body", t: "rich" },
    ],
    init: { heading: "", body: "Write your content here." },
  },
  split: {
    label: "Image + text",
    fields: [
      { k: "heading", label: "Heading", t: "text" },
      { k: "body", label: "Text", t: "rich" },
      { k: "points", label: "Bullet points (one per line, optional)", t: "lines" },
      { k: "image", label: "Image", t: "image" },
      { k: "alt", label: "Image alt text", t: "text" },
      { k: "side", label: "Image side: left or right", t: "text" },
      { k: "label", label: "Button label (optional)", t: "text" },
      { k: "href", label: "Button link", t: "text" },
    ],
    init: { heading: "Section heading", body: "Write a short paragraph here.", points: ["First point", "Second point"], image: "", alt: "", side: "right", label: "", href: "/contact-us" },
  },
  steps: {
    label: "Process steps",
    fields: [
      { k: "heading", label: "Heading", t: "text" },
      { k: "intro", label: "Intro", t: "area" },
      { k: "items", label: "Steps", t: "items", sub: [{ k: "title", label: "Title", t: "text" }, { k: "body", label: "Text", t: "area" }] },
    ],
    init: { heading: "How we work", intro: "", items: [{ title: "Discover", body: "We learn your goals." }, { title: "Plan", body: "We build a clear roadmap." }, { title: "Deliver", body: "We launch and improve." }] },
  },
  stats: {
    label: "Numbers strip",
    fields: [
      { k: "heading", label: "Heading (optional)", t: "text" },
      { k: "items", label: "Numbers", t: "items", sub: [{ k: "value", label: "Number (e.g. 500+)", t: "text" }, { k: "label", label: "Label", t: "text" }] },
    ],
    init: { heading: "", items: [{ value: "500+", label: "Projects" }, { value: "10+", label: "Years" }, { value: "98%", label: "Retention" }] },
  },
  image: {
    label: "Image",
    fields: [
      { k: "src", label: "Image", t: "image" },
      { k: "alt", label: "Alt text", t: "text" },
      { k: "caption", label: "Caption (optional)", t: "text" },
    ],
    init: { src: "", alt: "", caption: "" },
  },
  features: {
    label: "Feature cards",
    fields: [
      { k: "heading", label: "Heading", t: "text" },
      { k: "intro", label: "Intro", t: "area" },
      {
        k: "items",
        label: "Cards",
        t: "items",
        sub: [
          { k: "title", label: "Title", t: "text" },
          { k: "body", label: "Text", t: "area" },
          { k: "href", label: "Link (optional)", t: "text" },
        ],
      },
    ],
    init: { heading: "What we do", intro: "", items: [{ title: "Feature title", body: "Describe it briefly.", href: "" }] },
  },
  checklist: {
    label: "Checklist",
    fields: [
      { k: "heading", label: "Heading", t: "text" },
      { k: "intro", label: "Intro", t: "area" },
      { k: "items", label: "Items (one per line)", t: "lines" },
    ],
    init: { heading: "What is included", intro: "", items: ["First item", "Second item"] },
  },
  faq: {
    label: "FAQ",
    fields: [
      { k: "heading", label: "Heading", t: "text" },
      {
        k: "items",
        label: "Questions",
        t: "items",
        sub: [
          { k: "q", label: "Question", t: "text" },
          { k: "a", label: "Answer", t: "area" },
        ],
      },
    ],
    init: { heading: "Common questions", items: [{ q: "Question?", a: "Answer." }] },
  },
  cta: {
    label: "Call to action",
    fields: [
      { k: "title", label: "Title", t: "text" },
      { k: "text", label: "Text", t: "area" },
      { k: "label", label: "Button label", t: "text" },
      { k: "href", label: "Button link", t: "text" },
    ],
    init: { title: "Ready to start?", text: "Talk to our team today.", label: "Contact us", href: "/contact-us" },
  },
};

export const BLOCK_TYPES = Object.keys(BLOCKS) as BlockType[];
export const uid = () => Math.random().toString(36).slice(2, 10);
export const newBlock = (type: BlockType): Block => ({ id: uid(), type, ...structuredClone(BLOCKS[type].init) });

export const str = (v: unknown) => (typeof v === "string" ? v : "");
export const rows = (v: unknown) => (Array.isArray(v) ? (v as Record<string, string>[]) : []);
export const strs = (v: unknown) => (Array.isArray(v) ? (v as string[]) : []);
export const safeHref = (h: string) => (/^(\/|https?:\/\/|mailto:|tel:|#)/i.test(h) ? h : "/");
